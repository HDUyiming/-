#ifndef __JQ8900_H
#define __JQ8900_H
 
#include "sys.h"
 
#define SDA PBout(11)
 
void SendData ( u8 addr );    //���ͺ�����
void OnUart_GPIO(void);       //GPIO
 void delay_us2(u32 nTimer);
#endif
 

