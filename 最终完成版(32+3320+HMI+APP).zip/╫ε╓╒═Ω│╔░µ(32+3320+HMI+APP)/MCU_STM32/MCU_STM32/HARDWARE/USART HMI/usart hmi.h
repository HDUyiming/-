#ifndef _USARTHMI_H
#define _USARTHMI_H
int hmi_connect(void);
void judge(void);
void HMISends(char *buf1);
void HMISendb(u8 k)	;
void Send_end(void);
void HMISendstart(void);

#endif

