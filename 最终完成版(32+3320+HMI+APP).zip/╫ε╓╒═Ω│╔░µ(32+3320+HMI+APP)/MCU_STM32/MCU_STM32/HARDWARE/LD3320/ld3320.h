#ifndef __LD3320_H
#define __LD3320_H 
#include "ld3320.h"  

void ld3320_gpio(void);

#endif

